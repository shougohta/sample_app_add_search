class ApplicationMailer < ActionMailer::Base
  default from: "user@realdomain.com"
  layout "mailer"
end
